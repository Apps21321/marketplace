
<?php
$config = require __DIR__ . '/../config/config.php';
$db = new PDO(
    "mysql:host={$config['db']['host']};dbname={$config['db']['dbname']}",
    $config['db']['user'],
    $config['db']['pass']
);

// Получаем список ожидающих транзакций
$stmt = $db->prepare("SELECT * FROM transactions WHERE status = 'pending'");
$stmt->execute();
$pending = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($pending as $tx) {
    $txid = $tx['tx_hash'];
    $address = $tx['bitcoin_address'];
    $api_url = "{$config['btc_api']}/tx/$txid";

    $response = @file_get_contents($api_url);
    if ($response) {
        $tx_data = json_decode($response, true);
        if (isset($tx_data['status']) && $tx_data['status']['confirmed'] === true) {
            $confirmations = $tx_data['status']['block_height'] ? 6 : 0; // симуляция

            if ($confirmations >= 3) {
                // Обновляем транзакцию
                $update = $db->prepare("UPDATE transactions SET status = 'confirmed' WHERE id = ?");
                $update->execute([$tx['id']]);

                // Активируем пользователя
                $user = $db->prepare("UPDATE users SET status = 'active' WHERE id = ?");
                $user->execute([$tx['user_id']]);
            }
        }
    }
}
?>
