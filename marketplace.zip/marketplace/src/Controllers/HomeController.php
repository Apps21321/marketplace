<?php

class HomeController {
    public function index() {
        // Получаем категории из базы данных
        $pdo = new PDO("mysql:host=localhost;dbname=marketplace", "marketuser", "password");
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stmt = $pdo->query("SELECT * FROM categories");
        $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);

        include '../templates/home.php'; // Страница для отображения категорий
    }
}
