<?php

class CartController {
    public function viewCart() {
        // Получаем товары из корзины пользователя
        $userId = $_SESSION['user_id'];  // Получаем ID пользователя из сессии

        $pdo = new PDO("mysql:host=localhost;dbname=marketplace", "marketuser", "password");
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $stmt = $pdo->prepare("SELECT p.*, c.quantity FROM cart c JOIN products p ON c.product_id = p.id WHERE c.user_id = ?");
        $stmt->execute([$userId]);
        $cartItems = $stmt->fetchAll(PDO::FETCH_ASSOC);

        include '../templates/cart.php';  // Шаблон для корзины
    }

    public function addToCart() {
        // Добавление товара в корзину
        $productId = $_POST['product_id'];
        $userId = $_SESSION['user_id'];

        $pdo = new PDO("mysql:host=localhost;dbname=marketplace", "marketuser", "password");
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Проверяем, есть ли товар в корзине
        $stmt = $pdo->prepare("SELECT * FROM cart WHERE user_id = ? AND product_id = ?");
        $stmt->execute([$userId, $productId]);
        $cartItem = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($cartItem) {
            // Если товар уже есть в корзине, увеличиваем количество
            $stmt = $pdo->prepare("UPDATE cart SET quantity = quantity + 1 WHERE user_id = ? AND product_id = ?");
            $stmt->execute([$userId, $productId]);
        } else {
            // Если товара нет в корзине, добавляем
            $stmt = $pdo->prepare("INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, ?)");
            $stmt->execute([$userId, $productId, 1]);
        }

        echo "Товар добавлен в корзину!";
    }
}
