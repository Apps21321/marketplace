
<?php
require_once __DIR__ . '/../../config/config.php';

class AdminController {
private function db() {
    static $pdo = null;
    if ($pdo === null) {
        $config = require __DIR__ . '/../../config/config.php';
        $db = $config['db'];

        $pdo = new PDO("mysql:host={$db['host']};dbname={$db['dbname']}", $db['user'], $db['pass']);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
    return $pdo;
}


    public function index() {
        include '../templates/admin.php';
    }

    public function settings() {
        $pdo = $this->db();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $newPrice = floatval($_POST['access_price']);
            $stmt = $pdo->prepare("UPDATE settings SET value = ? WHERE `setting_key` = 'access_price'");
            $stmt->execute([$newPrice]);
            echo "<p style='color:lime;'>Сохранено!</p>";
        }

        $stmt = $pdo->prepare("SELECT value FROM settings WHERE `setting_key` = 'access_price'");
        $stmt->execute();
        $price = $stmt->fetchColumn();

        include '../templates/admin_settings.php';
    }

    public function transactions() {
        $pdo = $this->db();
        $sql = "SELECT t.*, u.jabber, u.type FROM transactions t JOIN users u ON t.user_id = u.id WHERE 1=1";
        $params = [];

        if (!empty($_GET['role'])) {
            $sql .= " AND u.type = ?";
            $params[] = $_GET['role'];
        }

        if (!empty($_GET['search'])) {
            $sql .= " AND (u.jabber LIKE ? OR t.tx_hash LIKE ?)";
            $params[] = '%' . $_GET['search'] . '%';
            $params[] = '%' . $_GET['search'] . '%';
        }

        $sql .= " ORDER BY t.created_at DESC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

        include '../templates/admin_transactions.php';
    }

    public function users() {
        $pdo = $this->db();
        $sql = "SELECT * FROM users WHERE 1=1";
        $params = [];

        if (!empty($_GET['role'])) {
            $sql .= " AND type = ?";
            $params[] = $_GET['role'];
        }

        if (!empty($_GET['search'])) {
            $sql .= " AND jabber LIKE ?";
            $params[] = '%' . $_GET['search'] . '%';
        }

        $sql .= " ORDER BY id ASC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);

        include '../templates/admin_users.php';
    }

    public function updateStatus() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['user_id'], $_POST['new_status'])) {
            $pdo = $this->db();
            $stmt = $pdo->prepare("UPDATE users SET status = ? WHERE id = ?");
            $stmt->execute([$_POST['new_status'], $_POST['user_id']]);
            echo "OK";
        } else {
            http_response_code(400);
            echo "Missing data.";
        }
    }

    public function deleteUser() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['user_id'])) {
            $pdo = $this->db();
            $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
            $stmt->execute([$_POST['user_id']]);
            echo "Пользователь удалён!";
        } else {
            echo "Некорректный запрос.";
        }
    }

    public function createUser() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['jabber'], $_POST['password'], $_POST['role'])) {
            $pdo = $this->db();
            $stmt = $pdo->prepare("INSERT INTO users (jabber, password_hash, type, status) VALUES (?, ?, ?, 'active')");
            $stmt->execute([$_POST['jabber'], password_hash($_POST['password'], PASSWORD_DEFAULT), $_POST['role']]);
            echo "Пользователь создан!";
        } else {
            echo "Некорректные данные.";
        }
    }

    public function getUserDetails() {
        if (!isset($_GET['user_id'])) {
            http_response_code(400);
            echo json_encode(['error' => 'User ID not provided']);
            return;
        }
        $pdo = $this->db();
        $stmt = $pdo->prepare("SELECT id, jabber FROM users WHERE id = ?");
        $stmt->execute([$_GET['user_id']]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$user) {
            http_response_code(404);
            echo json_encode(['error' => 'User not found']);
            return;
        }

        echo json_encode($user);
    }

    public function updateUser() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['user_id'])) {
            $pdo = $this->db();
            $jabber = $_POST['jabber'];
            $password = $_POST['password'];

            if (!empty($password)) {
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("UPDATE users SET jabber = ?, password = ? WHERE id = ?");
                $stmt->execute([$jabber, $hashedPassword, $_POST['user_id']]);
            } else {
                $stmt = $pdo->prepare("UPDATE users SET jabber = ? WHERE id = ?");
                $stmt->execute([$jabber, $_POST['user_id']]);
            }

            echo json_encode(['status' => 'success']);
        } else {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid request']);
        }
    }
	
	
    public function products() {
        $pdo = $this->db();
        $stmt = $pdo->query("SELECT * FROM products ORDER BY id DESC");
        $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
        include '../templates/admin_products.php';
    }

    public function createProduct() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = $_POST['name'];
            $price = floatval($_POST['price']);
            $sellerId = intval($_POST['seller_id']);

            $pdo = $this->db();
            $stmt = $pdo->prepare("INSERT INTO products (name, price, seller_id) VALUES (?, ?, ?)");
            $stmt->execute([$name, $price, $sellerId]);
            echo "OK";
        }
    }

    public function deleteProduct() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
            $pdo = $this->db();
            $stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
            $stmt->execute([$_POST['id']]);
            echo "DELETED";
        }
    }

    public function getProductDetails() {
        if (isset($_GET['id'])) {
            $pdo = $this->db();
            $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
            $stmt->execute([$_GET['id']]);
            $product = $stmt->fetch(PDO::FETCH_ASSOC);
            echo json_encode($product);
        } else {
            http_response_code(400);
            echo json_encode(['error' => 'ID required']);
        }
    }

    public function updateProduct() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
            $id = intval($_POST['id']);
            $name = $_POST['name'];
            $price = floatval($_POST['price']);

            $pdo = $this->db();
            $stmt = $pdo->prepare("UPDATE products SET name = ?, price = ? WHERE id = ?");
            $stmt->execute([$name, $price, $id]);
            echo "UPDATED";
        } else {
            http_response_code(400);
            echo "Missing data.";
        }
    }


    public function reviews() {
        $pdo = $this->db();
        $stmt = $pdo->query("SELECT * FROM reviews ORDER BY created_at DESC");
        $reviews = $stmt->fetchAll(PDO::FETCH_ASSOC);
        include '../templates/admin_reviews.php';
    }

    public function deleteReview() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
            $pdo = $this->db();
            $stmt = $pdo->prepare("DELETE FROM reviews WHERE id = ?");
            $stmt->execute([$_POST['id']]);
            echo "DELETED";
        } else {
            http_response_code(400);
            echo "Missing ID";
        }
    }


    public function categories() {
        $pdo = $this->db();
        $stmt = $pdo->query("SELECT * FROM categories ORDER BY id DESC");
        $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
        include '../templates/admin_categories.php';
    }

public function createCategory() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $name = $_POST['name'];
        $description = $_POST['description'];
        $image = '';

        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $image = '/uploads/' . $_FILES['image']['name'];
            move_uploaded_file($_FILES['image']['tmp_name'], $_SERVER['DOCUMENT_ROOT'] . $image);
        }

        $pdo = $this->db();
        $stmt = $pdo->prepare("INSERT INTO categories (name, description, image) VALUES (?, ?, ?)");
        $stmt->execute([$name, $description, $image]);

        header('Location: /admin/categories');
        exit;
    }
}


    public function deleteCategory() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
            $pdo = $this->db();
            $stmt = $pdo->prepare("DELETE FROM categories WHERE id = ?");
            $stmt->execute([$_POST['id']]);
            echo "DELETED";
        } else {
            http_response_code(400);
            echo "Missing ID";
        }
    }


    public function banners() {
        $pdo = $this->db();
        $stmt = $pdo->query("SELECT * FROM banners ORDER BY id DESC");
        $banners = $stmt->fetchAll(PDO::FETCH_ASSOC);
        include '../templates/admin_banners.php';
    }

    public function createBanner() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['title'])) {
            $pdo = $this->db();
            $stmt = $pdo->prepare("INSERT INTO banners (title, url, image) VALUES (?, ?, ?)");
            $stmt->execute([$_POST['title'], $_POST['url'], $_POST['image']]);
            echo "OK";
        } else {
            http_response_code(400);
            echo "Missing data";
        }
    }

    public function deleteBanner() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
            $pdo = $this->db();
            $stmt = $pdo->prepare("DELETE FROM banners WHERE id = ?");
            $stmt->execute([$_POST['id']]);
            echo "DELETED";
        } else {
            http_response_code(400);
            echo "Missing ID";
        }
    }


    public function announcements() {
        $pdo = $this->db();
        $stmt = $pdo->query("SELECT * FROM announcements ORDER BY created_at DESC");
        $announcements = $stmt->fetchAll(PDO::FETCH_ASSOC);
        include '../templates/admin_announcements.php';
    }

    public function createAnnouncement() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['text'])) {
            $pdo = $this->db();
            $stmt = $pdo->prepare("INSERT INTO announcements (text, created_at) VALUES (?, NOW())");
            $stmt->execute([$_POST['text']]);
            echo "OK";
        } else {
            http_response_code(400);
            echo "Missing data";
        }
    }

    public function deleteAnnouncement() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
            $pdo = $this->db();
            $stmt = $pdo->prepare("DELETE FROM announcements WHERE id = ?");
            $stmt->execute([$_POST['id']]);
            echo "DELETED";
        } else {
            http_response_code(400);
            echo "Missing ID";
        }
    }


    public function nav() {
        $pdo = $this->db();
        $stmt = $pdo->query("SELECT * FROM nav ORDER BY id DESC");
        $navs = $stmt->fetchAll(PDO::FETCH_ASSOC);
        include '../templates/admin_nav.php';
    }

    public function createNav() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['title']) && !empty($_POST['url'])) {
            $pdo = $this->db();
            $stmt = $pdo->prepare("INSERT INTO nav (title, url) VALUES (?, ?)");
            $stmt->execute([$_POST['title'], $_POST['url']]);
            echo "OK";
        } else {
            http_response_code(400);
            echo "Missing data";
        }
    }

    public function deleteNav() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
            $pdo = $this->db();
            $stmt = $pdo->prepare("DELETE FROM nav WHERE id = ?");
            $stmt->execute([$_POST['id']]);
            echo "DELETED";
        } else {
            http_response_code(400);
            echo "Missing ID";
        }
    }


    public function tickets() {
        $pdo = $this->db();
        $stmt = $pdo->query("SELECT t.*, u.jabber AS user_jabber FROM tickets t JOIN users u ON t.user_id = u.id ORDER BY t.created_at DESC");
        $tickets = $stmt->fetchAll(PDO::FETCH_ASSOC);
        include '../templates/admin_tickets.php';
    }

    public function deleteTicket() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
            $pdo = $this->db();
            $stmt = $pdo->prepare("DELETE FROM tickets WHERE id = ?");
            $stmt->execute([$_POST['id']]);
            echo "DELETED";
        } else {
            http_response_code(400);
            echo "Missing ID";
        }
    }

	
    public function logs() {
        $pdo = $this->db();
        $stmt = $pdo->query("SELECT l.*, u.jabber AS user_jabber FROM activity_logs l JOIN users u ON l.user_id = u.id ORDER BY l.created_at DESC");
        $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
        include '../templates/admin_logs.php';
    }

    public function logAction($userId, $action) {
        $pdo = $this->db();
        $stmt = $pdo->prepare("INSERT INTO activity_logs (user_id, action) VALUES (?, ?)");
        $stmt->execute([$userId, $action]);
    }

	
}
