<?php

class ProductController {
    public function showProduct() {
        // Получаем ID товара из URL
        $productId = $_GET['id'];

        // Получаем товар из базы данных
        $pdo = new PDO("mysql:host=localhost;dbname=marketplace", "marketuser", "password");
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
        $stmt->execute([$productId]);
        $product = $stmt->fetch(PDO::FETCH_ASSOC);

        // Получаем информацию о продавце
        $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$product['user_id']]);
        $seller = $stmt->fetch(PDO::FETCH_ASSOC);

        include '../templates/product_details.php';  // Страница с подробностями товара
    }
}
