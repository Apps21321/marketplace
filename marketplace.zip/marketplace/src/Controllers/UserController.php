<?php
// Handles user logic