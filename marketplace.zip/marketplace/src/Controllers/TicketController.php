<?php
// Ticket system logic