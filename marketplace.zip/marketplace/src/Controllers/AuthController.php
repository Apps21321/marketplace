<?php
class AuthController {
    public function handleRegister($data) {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        if (!isset($_SESSION['captcha']) || strtolower($data['captcha']) !== strtolower($_SESSION['captcha'])) {
            die('Неверная капча');
        }

        $jabber = trim($data['jabber']);
        $password = password_hash($data['password'], PASSWORD_DEFAULT);
        $type = in_array($data['type'], ['buyer', 'seller']) ? $data['type'] : 'buyer';

        try {
            $pdo = new PDO("mysql:host=localhost;dbname=marketplace", "marketuser", "password");
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            $check = $pdo->prepare("SELECT COUNT(*) FROM users WHERE jabber = ?");
            $check->execute([$jabber]);
            if ($check->fetchColumn() > 0) {
                die('Такой Jabber уже зарегистрирован.');
            }

            $stmt = $pdo->prepare("INSERT INTO users (jabber, password_hash, type) VALUES (?, ?, ?)");
            $stmt->execute([$jabber, $password, $type]);

            $userId = $pdo->lastInsertId();
            $_SESSION['user_id'] = $userId;
            $_SESSION['user_type'] = $type;

            header("Location: /payment");
            exit;
        } catch (PDOException $e) {
            echo "<p style='color:red;'>Ошибка: " . $e->getMessage() . "</p>";
        }
    }

    public function handleLogin($data) {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        if (!isset($data['jabber'], $data['password'], $data['captcha'])) {
            die('Данные не переданы');
        }

        if (!isset($_SESSION['captcha']) || strtolower($data['captcha']) !== strtolower($_SESSION['captcha'])) {
            die('Неверная капча');
        }

        $jabber = trim($data['jabber']);
        $password = $data['password'];

        try {
            $pdo = new PDO("mysql:host=localhost;dbname=marketplace", "marketuser", "password");
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            $stmt = $pdo->prepare("SELECT * FROM users WHERE jabber = ?");
            $stmt->execute([$jabber]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user && password_verify($password, $user['password_hash'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_type'] = $user['type'];
                $_SESSION['jabber'] = $user['jabber'];

                // ✅ Подключаем логгер и логируем вход
                require_once __DIR__ . '/../Logger.php';
				file_put_contents('/tmp/test_login.log', "Логгер вызван\\n", FILE_APPEND);
                logEvent($user['id'], 'Вход в систему');

                if ($_SESSION['user_type'] === 'admin' || $_SESSION['user_type'] === 'moderator') {
                    header('Location: /admin');
                } else {
                    header('Location: /product');
                }
                exit;
            } else {
                echo "<p style='color:red;'>Неверный логин или пароль</p>";
            }
        } catch (PDOException $e) {
            echo "<p style='color:red;'>Ошибка: " . $e->getMessage() . "</p>";
        }
    }
}
