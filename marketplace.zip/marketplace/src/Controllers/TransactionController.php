<?php
// Bitcoin payments logic