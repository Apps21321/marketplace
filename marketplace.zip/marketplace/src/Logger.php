<?php

function logEvent($userId, $action) {
    global $config;

    try {
        $config = require __DIR__ . '/../config/config.php';  // Берём конфиг

$pdo = new PDO(
    "mysql:host={$config['db']['host']};dbname={$config['db']['dbname']}",
    $config['db']['user'],
    $config['db']['pass']
);

        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $stmt = $pdo->prepare("INSERT INTO activity_logs (user_id, action) VALUES (?, ?)");
        $stmt->execute([$userId, $action]);
    } catch (Exception $e) {
        file_put_contents('/tmp/logger_debug.log', "Ошибка: " . $e->getMessage() . "\n", FILE_APPEND);
    }
}