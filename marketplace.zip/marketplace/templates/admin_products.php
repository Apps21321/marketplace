
<?php include __DIR__ . '/header.php'; ?>
<h2>Управление товарами</h2>
<script src="/assets/js/products.js"></script>

<h3>Добавить товар</h3>
<form id="createProductForm" method="post" action="/admin/products/create">
    <label for="product_name">Название:</label>
    <input type="text" name="name" id="product_name" required>
    <label for="product_price">Цена:</label>
    <input type="number" name="price" id="product_price" required>
    <label for="seller_id">ID продавца:</label>
    <input type="number" name="seller_id" id="seller_id" required>
    <button type="submit">Добавить</button>
</form>

<table style="width:100%; border:1px solid #444; border-collapse:collapse; margin-top:20px;">
    <thead style="background-color:#333; color:#fff;">
        <tr>
            <th>ID</th>
            <th>Название</th>
            <th>Цена</th>
            <th>Продавец</th>
            <th>Действия</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($products as $product): ?>
        <tr id="product-<?= $product['id'] ?>">
            <td><?= htmlspecialchars($product['id']) ?></td>
            <td><?= htmlspecialchars($product['name']) ?></td>
            <td><?= htmlspecialchars($product['price']) ?></td>
            <td><?= htmlspecialchars($product['seller_id']) ?></td>
            <td>
                <button class="edit-product" data-product-id="<?= $product['id'] ?>">Изменить</button>
                <button class="delete-product" data-product-id="<?= $product['id'] ?>">Удалить</button>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<!-- Модальное окно для редактирования товара -->
<div id="editProductModal" style="display:none; position:fixed; top:50%; left:50%; transform:translate(-50%, -50%); background:#fff; padding:20px; border:1px solid #ccc;">
    <h3>Редактировать товар</h3>
    <form id="editProductForm">
        <input type="hidden" name="id" id="edit_product_id">
        <label for="edit_product_name">Название:</label>
        <input type="text" name="name" id="edit_product_name" required>
        <label for="edit_product_price">Цена:</label>
        <input type="number" name="price" id="edit_product_price" required>
        <button type="submit">Сохранить</button>
        <button type="button" id="closeEditProductModal">Отмена</button>
    </form>
</div>

<?php include __DIR__ . '/footer.php'; ?>
