
<?php include __DIR__ . '/header.php'; ?>
<h2>Тикеты</h2>
<script src="/assets/js/tickets.js"></script>

<table style="width:100%; border:1px solid #444; border-collapse:collapse; margin-top:20px;">
    <thead style="background-color:#333; color:#fff;">
        <tr>
            <th>ID</th>
            <th>Пользователь</th>
            <th>Сообщение</th>
            <th>Дата</th>
            <th>Действия</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($tickets as $ticket): ?>
        <tr id="ticket-<?= $ticket['id'] ?>">
            <td><?= htmlspecialchars($ticket['id']) ?></td>
            <td><?= htmlspecialchars($ticket['user_jabber']) ?></td>
            <td><?= nl2br(htmlspecialchars($ticket['message'])) ?></td>
            <td><?= htmlspecialchars($ticket['created_at']) ?></td>
            <td><button class="delete-ticket" data-id="<?= $ticket['id'] ?>">Удалить</button></td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?php include __DIR__ . '/footer.php'; ?>
