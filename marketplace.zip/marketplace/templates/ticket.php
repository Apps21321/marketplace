
<?php include 'header.php'; ?>
<div class="container">
  <div class="form-box">
    <h2>Тикеты</h2>
    <div style="max-height: 300px; overflow-y: auto; background: #1a1a1a; padding: 10px; border-radius: 5px; margin-bottom: 20px;">
      <p><strong>support:</strong> Добро пожаловать! Чем можем помочь?</p>
      <p><strong>вы:</strong> У меня вопрос по товару.</p>
    </div>
    <form method="post" action="/ticket">
      <input type="text" name="message" placeholder="Введите сообщение..." required>
      <button type="submit">Отправить</button>
    </form>
  </div>
</div>
<?php include 'footer.php'; ?>
