<?php include __DIR__ . '/header.php'; ?>
<link rel="stylesheet" href="/assets/css/style.css">
<div class="container">
  <div class="form-box">
    <h2>Панель администратора</h2>
    <ul style="list-style: none; padding: 0;">
      <li><a href='/admin/settings'>Настройки оплаты</a></li>
<li><a href='/admin/transactions'>Транзакции</a></li>
<li><a href='/admin/users'>Управление пользователями</a></li>
<li><a href='/admin/products'>Управление товарами</a></li>
<li><a href='/admin/reviews'>Отзывы</a></li>
<li><a href='/admin/categories'>Категории</a></li>
<li><a href='/admin/banners'>Баннеры и фон</a></li>
<li><a href='/admin/announcements'>Объявления</a></li>
<li><a href='/admin/nav'>Кнопки хедера</a></li>
<li><a href='/admin/tickets'>Тикеты</a></li>
<li><a href='/admin/logs'>Логи активности</a></li>
<li><a href='/admin/broadcast'>Массовая рассылка</a></li>
    </ul>
  </div>
</div>
<?php include __DIR__ . '/footer.php'; ?>

