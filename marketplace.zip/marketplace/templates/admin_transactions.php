
<?php include 'header.php'; ?>
<div class="container">
  <div class="form-box">
    <h2>Транзакции</h2>

    <form method="get" action="/admin/transactions" style="margin-bottom:20px;">
      <label for="role">Фильтр по роли:</label>
      <select name="role" id="role">
        <option value="">Все</option>
        <option value="buyer" <?= isset($_GET['role']) && $_GET['role'] == 'buyer' ? 'selected' : '' ?>>Покупатели</option>
        <option value="seller" <?= isset($_GET['role']) && $_GET['role'] == 'seller' ? 'selected' : '' ?>>Продавцы</option>
      </select>
      <label for="search">Поиск:</label>
      <input type="text" name="search" id="search" value="<?= htmlspecialchars($_GET['search'] ?? '') ?>" placeholder="Jabber или хеш">
      <button type="submit">Применить</button>
    </form>

    <table style="width:100%; border-collapse:collapse; background:#1a1a1a;">
      <thead style="background:#333; color:#fff;">
        <tr>
          <th style="border:1px solid #444; padding:10px;">Дата</th>
          <th style="border:1px solid #444; padding:10px;">Пользователь</th>
          <th style="border:1px solid #444; padding:10px;">Роль</th>
          <th style="border:1px solid #444; padding:10px;">Сумма</th>
          <th style="border:1px solid #444; padding:10px;">Хеш</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($transactions as $transaction): ?>
          <tr>
            <td style="border:1px solid #444; padding:10px;"><?= htmlspecialchars($transaction['created_at']) ?></td>
            <td style="border:1px solid #444; padding:10px;"><?= htmlspecialchars($transaction['jabber']) ?></td>
            <td style="border:1px solid #444; padding:10px;"><?= htmlspecialchars($transaction['type']) ?></td>
            <td style="border:1px solid #444; padding:10px;"><?= htmlspecialchars($transaction['amount']) ?> USD</td>
            <td style="border:1px solid #444; padding:10px;"><?= htmlspecialchars($transaction['tx_hash']) ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php include 'footer.php'; ?>
