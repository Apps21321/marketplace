
  <hr>
  <footer style="text-align: center; padding: 10px; color: #aaa;">
    &copy; 2025 Marketplace
  </footer>
</body>
</html>
