
<?php include 'header.php'; ?>
<div class="container">
  <div class="form-box">
    <h2>Minecraft Premium</h2>
    <p><strong>Описание:</strong> Доступ к лицензии, смена почты, гарантия 24 часа.</p>
    <p><strong>Категория:</strong> Игры</p>
    <p><strong>Продавец:</strong> <a href="/u/stealth">stealth</a></p>
    <p><strong>Цена:</strong> 5.00 USD</p>
    <form method="post" action="/cart/add">
      <input type="hidden" name="product_id" value="1">
      <button type="submit">Добавить в корзину</button>
    </form>

    <h3 style="margin-top: 20px;">Отзывы о товаре:</h3>
    <div style="background:#1a1a1a; padding:10px; border-radius:5px;">
      <p><strong>Покупатель:</strong> Аккаунт рабочий, всё чётко.</p>
      <p><strong>Покупатель:</strong> Быстрая доставка и вежливый продавец.</p>
    </div>
  </div>
</div>
<?php include 'footer.php'; ?>
