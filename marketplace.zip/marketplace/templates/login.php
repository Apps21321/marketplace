
<link rel="stylesheet" href="/assets/css/style.css">
<div class="container-narrow">
  <div class="form-box">
    <h2>Вход</h2>
    <form method="post" action="/login">
      <input type="text" name="jabber" placeholder="Jabber" required>
      <input type="password" name="password" placeholder="Пароль" required>
	  <img src="/captcha.php" alt="Капча">
<input type="text" name="captcha" placeholder="Введите капчу" required>

      <button type="submit">Войти</button>
    </form>
  </div>
</div>

