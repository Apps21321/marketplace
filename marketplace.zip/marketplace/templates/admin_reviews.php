
<?php include __DIR__ . '/header.php'; ?>
<h2>Управление отзывами</h2>
<script src="/assets/js/reviews.js"></script>

<table style="width:100%; border:1px solid #444; border-collapse:collapse; margin-top:20px;">
    <thead style="background-color:#333; color:#fff;">
        <tr>
            <th>ID</th>
            <th>От кого</th>
            <th>Кому</th>
            <th>Оценка</th>
            <th>Комментарий</th>
            <th>Дата</th>
            <th>Действия</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($reviews as $review): ?>
        <tr id="review-<?= $review['id'] ?>">
            <td><?= htmlspecialchars($review['id']) ?></td>
            <td><?= htmlspecialchars($review['from_user']) ?></td>
            <td><?= htmlspecialchars($review['to_user']) ?></td>
            <td><?= htmlspecialchars($review['rating']) ?></td>
            <td><?= htmlspecialchars($review['comment']) ?></td>
            <td><?= htmlspecialchars($review['created_at']) ?></td>
            <td>
                <button class="delete-review" data-review-id="<?= $review['id'] ?>">Удалить</button>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?php include __DIR__ . '/footer.php'; ?>
