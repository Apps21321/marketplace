
<?php include 'header.php'; ?>
<div class="container">
  <div class="form-box">
    <h2>Профиль пользователя</h2>
    <p><strong>Jabber:</strong> stealth@xmpp.is</p>
    <p><strong>Роль:</strong> Продавец</p>
    <p><strong>Рейтинг:</strong> ⭐ 4.8 (24 отзыва)</p>
    <p><strong>Завершённых сделок:</strong> 58</p>

    <h3 style="margin-top:20px;">Отзывы:</h3>
    <div style="background:#1a1a1a; padding:10px; border-radius:5px;">
      <p><strong>Покупатель:</strong> Всё прошло отлично!</p>
      <p><strong>Покупатель:</strong> Быстрая доставка. Рекомендую!</p>
    </div>

    <h3 style="margin-top:20px;">Оставить отзыв:</h3>
    <form method="post" action="/profile/review">
      <input type="hidden" name="user_id" value="1">
      <input type="number" name="rating" placeholder="Оценка от 1 до 5" min="1" max="5" required>
      <input type="text" name="review_text" placeholder="Ваш отзыв..." required>
      <button type="submit">Оставить отзыв</button>
    </form>
  </div>
</div>
<?php include 'footer.php'; ?>
