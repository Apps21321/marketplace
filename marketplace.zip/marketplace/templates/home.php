<?php include __DIR__ . '/header.php'; ?>

<h2>Категории</h2>
<div class="category-container">
    <?php foreach ($categories as $cat): ?>
        <div class="category-item">
           <a href="/category/<?= $cat['id'] ?>">Перейти в категорию</a>
                <div class="category-name"><?= htmlspecialchars($cat['name']) ?></div>
                <div class="category-description"><?= htmlspecialchars($cat['description']) ?></div>
                <div class="category-image" style="background-image: url('<?= htmlspecialchars($cat['image']) ?>');"></div>
            </a>
        </div>
    <?php endforeach; ?>
</div>

<?php include __DIR__ . '/footer.php'; ?>
