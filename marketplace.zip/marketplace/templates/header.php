<?php
// В header.php, если у тебя есть информация о роли в $_SESSION
if (isset($_SESSION['user_type']) && ($_SESSION['user_type'] === 'admin' || $_SESSION['user_type'] === 'moderator')): ?>
<nav style="background-color: #333; padding: 10px;">
    <a href="/admin" style="color: #fff; text-decoration: none;">← Назад в админ-панель</a>
</nav>
<?php endif; ?>

<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <title>Marketplace</title>
  <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
  <header>
    <h1 style="color: #eee; background-color: #222; padding: 10px;">MARKETPLACE</h1>
    <nav style="padding: 10px;">
      <a href="/">Главная</a> |
      <a href="/register">Регистрация</a> |
      <a href="/login">Вход</a>
    </nav>
    <hr>
  </header>
