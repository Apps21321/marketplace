
<?php include __DIR__ . '/header.php'; ?>
<script src="/assets/js/user.js"></script>
<h2>Управление пользователями</h2>

<form method="get" action="/admin/users" style="margin-bottom:20px;">
  <label for="role_filter">Фильтр по роли:</label>
  <select name="role" id="role_filter">
    <option value="">Все</option>
    <option value="buyer">Покупатели</option>
    <option value="seller">Продавцы</option>
    <option value="admin">Администраторы</option>
    <option value="moderator">Модераторы</option>
  </select>
  
  <label for="search_jabber">Поиск по Jabber:</label>
  <input type="text" name="search" id="search_jabber" placeholder="Введите Jabber" value="<?= htmlspecialchars($_GET['search'] ?? '') ?>">
  
  <button type="submit">Применить</button>
</form>

<h3>Создать нового пользователя</h3>
<form id="createUserForm" method="post" action="/admin/users/create" style="margin-bottom:20px;">
  <label for="new_jabber">Jabber:</label>
  <input type="text" id="new_jabber" name="jabber" required placeholder="user@example.com">

  <label for="new_password">Пароль:</label>
  <input type="password" id="new_password" name="password" required placeholder="Введите пароль">

  <label for="new_role">Роль:</label>
  <select id="new_role" name="role">
    <option value="buyer">Покупатель</option>
    <option value="seller">Продавец</option>
    <option value="admin">Администратор</option>
    <option value="moderator">Модератор</option>
  </select>

  <button type="submit">Создать</button>
</form>

<p id="responseMessage" style="display:none; color:green;">Пользователь создан!</p>

<table style="width:100%; border:1px solid #444; border-collapse:collapse; margin-top:20px;">
    <thead style="background-color:#333; color:#fff;">
        <tr>
            <th>ID</th>
            <th>Jabber</th>
            <th>Роль</th>
            <th>Статус</th>
            <th>Действия</th>
        </tr>
    </thead>
<tbody>
    <?php foreach ($users as $user): ?>
        <tr id="user-<?= htmlspecialchars($user['id']) ?>">
            <td><?= htmlspecialchars($user['id']) ?></td>
            <td><?= htmlspecialchars($user['jabber']) ?></td>
            <td><?= htmlspecialchars($user['type']) ?></td>
            <td class="user-status"><?= htmlspecialchars($user['status']) ?></td>
            <td>
                <button class="toggle-status" data-user-id="<?= htmlspecialchars($user['id']) ?>" data-current-status="<?= htmlspecialchars($user['status']) ?>">
                    <?= $user['status'] === 'active' ? 'Деактивировать' : 'Активировать' ?>
                </button>
                <button class="delete-user" data-user-id="<?= htmlspecialchars($user['id']) ?>">Удалить</button>
                <button class="edit-user" data-user-id="<?= htmlspecialchars($user['id']) ?>">Изменить</button>
            </td>
        </tr>
    <?php endforeach; ?>
</tbody>
</table>

<!-- Модальное окно редактирования -->
<div id="editUserModal" style="display:none; position:fixed; top:50%; left:50%; transform:translate(-50%, -50%); background-color:white; border:1px solid #ccc; padding:20px; z-index:1000;">
    <h2>Редактировать пользователя</h2>
    <form id="editUserForm">
        <input type="hidden" name="user_id" id="edit_user_id">
        <label for="edit_jabber">Jabber:</label>
        <input type="text" name="jabber" id="edit_jabber">
        <label for="edit_password">Пароль:</label>
        <input type="password" name="password" id="edit_password">
        <button type="submit">Сохранить</button>
        <button type="button" id="closeEditModal">Отмена</button>
    </form>
</div>

<?php include __DIR__ . '/footer.php'; ?>
