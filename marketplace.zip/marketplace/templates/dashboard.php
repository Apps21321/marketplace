
<?php include 'header.php'; ?>
<div class="container">
  <div class="form-box">
    <h2>Добро пожаловать в Marketplace!</h2>

    <?php if (isset($_SESSION['user_id'])): ?>
      <p><strong>Вы вошли как:</strong> <?php echo htmlspecialchars($_SESSION['user_type']); ?> [ID: <?php echo $_SESSION['user_id']; ?>]</p>
      <form method="post" action="/logout">
        <button type="submit">Выйти</button>
      </form>
    <?php else: ?>
      <p><a href="/register">Регистрация</a> | <a href="/login">Вход</a></p>
    <?php endif; ?>

    <ul style="list-style: none; padding-left: 0;">
      <li>🔍 Просматривать товары на <a href="/product">маркетплейсе</a></li>
      <li>🛒 Добавлять в <a href="/cart">корзину</a> и оформлять заказы</li>
      <li>💬 Общаться с продавцами через <a href="/ticket">тикеты</a></li>
      <li>👤 Смотреть <a href="/u/stealth">профили пользователей</a></li>
      <li>🛠 Если вы админ — <a href="/admin">панель управления</a></li>
    </ul>
  </div>
</div>
<?php include 'footer.php'; ?>
