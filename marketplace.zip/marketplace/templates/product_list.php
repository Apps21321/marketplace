<h2>Product List</h2>
<?php include 'header.php'; ?>
<div class="container">
  <div class="form-box">
    <h2>Список товаров</h2>
    <div style="background:#1a1a1a; border-radius:10px; padding:10px;">
      <div style="margin-bottom:15px; border-bottom:1px solid #333; padding-bottom:10px;">
        <h3 style="margin:0;">Minecraft Premium</h3>
        <p>Аккаунт с доступом. Гарантия 24 часа.</p>
        <p><strong>Цена:</strong> 5.00 USD</p>
        <button>Купить</button>
      </div>
      <div style="margin-bottom:15px; border-bottom:1px solid #333; padding-bottom:10px;">
        <h3 style="margin:0;">Steam Random</h3>
        <p>Случайный аккаунт, от 1 до 20 игр.</p>
        <p><strong>Цена:</strong> 2.50 USD</p>
        <button>Купить</button>
      </div>
    </div>
  </div>
</div>
<?php include 'footer.php'; ?>
