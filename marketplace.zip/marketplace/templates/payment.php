<?php include 'header.php'; ?>
<?php
try {
    // Подключаемся к базе данных
    $pdo = new PDO("mysql:host=localhost;dbname=marketplace", "marketuser", "password");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Получаем цену доступа
    $stmt = $pdo->prepare("SELECT value FROM settings WHERE setting_key = 'access_price'");
    $stmt->execute();
    $price = $stmt->fetchColumn();

    // Получаем xpub
    $stmt = $pdo->prepare("SELECT value FROM settings WHERE setting_key = 'xpub'");
    $stmt->execute();
    $xpub = $stmt->fetchColumn();

    // Генерируем новый BTC-адрес (вставьте свою библиотеку или метод)
    // Здесь должен быть вызов функции, которая на основе xpub выдаёт новый BTC-адрес
    // Например:
    $btcAddress = generateBitcoinAddressFromXpub($xpub); // Вам нужна реализация этой функции

    if (!$btcAddress) {
        throw new Exception("Ошибка генерации BTC-адреса");
    }
} catch (Exception $e) {
    // Обработка ошибки
    $price = "Неизвестно";
    $btcAddress = "Ошибка получения адреса";
}
?>
<div class="container">
  <div class="form-box">
    <h2>Оплата доступа</h2>

    <p>Для получения полного доступа к маркетплейсу необходимо оплатить активацию аккаунта.</p>
    <p><strong>Сумма:</strong> <?= htmlspecialchars($price) ?> USD (в BTC по курсу)</p>
    <p><strong>BTC-адрес для оплаты:</strong></p>
    <code style="display:block; text-align:center; background:#000; padding:10px; margin:10px 0;"><?= htmlspecialchars($btcAddress) ?></code>
    <p>После 3 подтверждений ваша учётная запись будет активирована автоматически.</p>
    <p>Проверка оплаты происходит каждые 5 минут.</p>

    <p style="margin-top:20px; font-size:14px; color:#aaa;">
      Вы можете связаться с администратором через тикеты после активации.
    </p>
  </div>
</div>
<?php include 'footer.php'; ?>

<?php
// Пример функции генерации BTC-адреса (должна быть подключена библиотека)
function generateBitcoinAddressFromXpub($xpub) {
    // Подключите библиотеку, например, PHP библиотеку для работы с xpub.
    // Здесь должен быть вызов библиотеки или API, которое возвращает новый адрес.
    // Этот код нужно заменить на реальную логику генерации:
    return "bc1qgeneratedaddress1234"; // это пример, замените его на реальный вызов
}
?>
