<?php include __DIR__ . '/header.php'; ?>
<h2>Управление категориями</h2>
<script src="/assets/js/categories.js"></script>

<h3>Добавить категорию</h3>
<form id="createCategoryForm" method="post" action="/admin/categories/create" enctype="multipart/form-data">
    <label for="cat_name">Название категории:</label>
    <input type="text" name="name" id="cat_name" required>
    
    <label for="cat_description">Описание:</label>
    <textarea name="description" id="cat_description" required></textarea>

    <label for="cat_image">Изображение категории:</label>
    <input type="file" name="image" id="cat_image" accept="image/*">

    <button type="submit">Добавить</button>
</form>

<h3>Список категорий</h3>
<table style="width:100%; border:1px solid #444; border-collapse:collapse; margin-top:20px;">
    <thead style="background-color:#333; color:#fff;">
        <tr>
            <th>ID</th>
            <th>Название</th>
            <th>Описание</th>
            <th>Изображение</th>
            <th>Действия</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($categories as $cat): ?>
        <tr id="category-<?= $cat['id'] ?>">
            <td><?= htmlspecialchars($cat['id']) ?></td>
            <td><?= htmlspecialchars($cat['name']) ?></td>
            <td><?= htmlspecialchars($cat['description']) ?></td>
            <td><img src="<?= htmlspecialchars($cat['image']) ?>" width="100px" /></td>
            <td>
                <button class="delete-category" data-id="<?= $cat['id'] ?>">Удалить</button>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?php include __DIR__ . '/footer.php'; ?>
