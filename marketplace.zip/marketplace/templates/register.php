
<link rel="stylesheet" href="/assets/css/style.css">
<div class="container-narrow">
  <div class="form-box">
    <h2>Регистрация</h2>
    <form method="post" action="/register">
      <input type="text" name="jabber" placeholder="Jabber" required>
      <input type="password" name="password" placeholder="Пароль" required>

      <p>Тип аккаунта:</p>
      <label><input type="radio" name="type" value="buyer" required> Покупатель</label><br>
      <label><input type="radio" name="type" value="seller" required> Продавец</label>

      <br><br>
      <img src="/captcha.php" alt="Капча">
      <input type="text" name="captcha" placeholder="Введите капчу" required>
      <button type="submit">Зарегистрироваться</button>
    </form>
  </div>
</div>

