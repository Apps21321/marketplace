
<?php include __DIR__ . '/header.php'; ?>
<h2>Логи активности</h2>
<script src="/assets/js/logs.js"></script>

<table style="width:100%; border:1px solid #444; border-collapse:collapse; margin-top:20px;">
    <thead style="background-color:#333; color:#fff;">
        <tr>
            <th>ID</th>
            <th>Пользователь</th>
            <th>Действие</th>
            <th>Дата</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($logs as $log): ?>
        <tr>
            <td><?= htmlspecialchars($log['id']) ?></td>
            <td><?= htmlspecialchars($log['user_jabber']) ?></td>
            <td><?= htmlspecialchars($log['action']) ?></td>
            <td><?= htmlspecialchars($log['created_at']) ?></td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?php include __DIR__ . '/footer.php'; ?>
