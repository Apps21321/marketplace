<?php include __DIR__ . '/header.php'; ?>

<h2>Ваша корзина</h2>

<div class="cart-items">
    <?php foreach ($cartItems as $item): ?>
        <div class="cart-item">
            <div class="cart-item-name"><?= htmlspecialchars($item['name']) ?></div>
            <div class="cart-item-price"><?= htmlspecialchars($item['price']) ?>$</div>
            <div class="cart-item-quantity"><?= htmlspecialchars($item['quantity']) ?></div>
        </div>
    <?php endforeach; ?>
</div>

<div class="cart-total">
    <span>Итого: </span>
    <span>
        <?php 
            $total = 0;
            foreach ($cartItems as $item) {
                $total += $item['price'] * $item['quantity'];
            }
            echo $total;
        ?>$
    </span>
</div>

<button class="checkout-button">Перейти к оплате</button>

<?php include __DIR__ . '/footer.php'; ?>
