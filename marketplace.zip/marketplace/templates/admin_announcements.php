
<?php include __DIR__ . '/header.php'; ?>
<h2>Объявления</h2>
<script src="/assets/js/announcements.js"></script>

<h3>Добавить объявление</h3>
<form id="createAnnouncementForm" method="post" action="/admin/announcements/create">
    <label for="announcement_text">Текст:</label><br>
    <textarea name="text" id="announcement_text" rows="4" cols="50" required></textarea><br>
    <button type="submit">Опубликовать</button>
</form>

<table style="width:100%; border:1px solid #444; border-collapse:collapse; margin-top:20px;">
    <thead style="background-color:#333; color:#fff;">
        <tr>
            <th>ID</th>
            <th>Текст</th>
            <th>Дата</th>
            <th>Действия</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($announcements as $a): ?>
        <tr id="announcement-<?= $a['id'] ?>">
            <td><?= htmlspecialchars($a['id']) ?></td>
            <td><?= nl2br(htmlspecialchars($a['text'])) ?></td>
            <td><?= htmlspecialchars($a['created_at']) ?></td>
            <td><button class="delete-announcement" data-id="<?= $a['id'] ?>">Удалить</button></td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?php include __DIR__ . '/footer.php'; ?>
