
<?php include 'header.php'; ?>
<div class="container-narrow">
  <div class="form-box">
    <h2>Настройки оплаты</h2>
    <form method="post" action="/admin/settings">
      <label for="access_price">Стоимость доступа (в USD):</label>
      <input type="number" step="0.01" name="access_price" value="<?php echo htmlspecialchars($price); ?>" required>
      <button type="submit">Сохранить</button>
    </form>
  </div>
</div>
<?php include 'footer.php'; ?>
