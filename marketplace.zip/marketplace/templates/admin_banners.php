
<?php include __DIR__ . '/header.php'; ?>
<h2>Баннеры и фон</h2>
<script src="/assets/js/banners.js"></script>

<h3>Добавить баннер</h3>
<form id="createBannerForm" method="post" action="/admin/banners/create">
    <label for="banner_title">Заголовок:</label>
    <input type="text" name="title" id="banner_title" required>
    <label for="banner_url">Ссылка:</label>
    <input type="text" name="url" id="banner_url">
    <label for="banner_image">URL изображения:</label>
    <input type="text" name="image" id="banner_image">
    <button type="submit">Добавить</button>
</form>

<table style="width:100%; border:1px solid #444; border-collapse:collapse; margin-top:20px;">
    <thead style="background-color:#333; color:#fff;">
        <tr>
            <th>ID</th>
            <th>Заголовок</th>
            <th>Ссылка</th>
            <th>Изображение</th>
            <th>Действия</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($banners as $banner): ?>
        <tr id="banner-<?= $banner['id'] ?>">
            <td><?= htmlspecialchars($banner['id']) ?></td>
            <td><?= htmlspecialchars($banner['title']) ?></td>
            <td><?= htmlspecialchars($banner['url']) ?></td>
            <td><img src="<?= htmlspecialchars($banner['image']) ?>" width="100"></td>
            <td>
                <button class="delete-banner" data-id="<?= $banner['id'] ?>">Удалить</button>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?php include __DIR__ . '/footer.php'; ?>
