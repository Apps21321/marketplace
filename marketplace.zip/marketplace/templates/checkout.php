
<?php include 'header.php'; ?>
<div class="container">
  <div class="form-box">
    <h2>Оформление заказа</h2>

    <p><strong>Товар:</strong> Minecraft Premium</p>
    <p><strong>Цена:</strong> 5.00 USD</p>

    <h3 style="margin-top: 20px;">Способ оплаты:</h3>
    <p>Оплата через Bitcoin</p>

    <div style="background:#1a1a1a; padding:15px; border-radius:5px; text-align:center; margin: 20px 0;">
      <p>Отправьте 5.00 USD в BTC на адрес:</p>
      <code style="background:#000; padding: 5px 10px; display: inline-block;">bc1qexamplebtcaddress</code>
      <p>После 3 подтверждений заказ активируется автоматически.</p>
    </div>

    <p>Вы также получите подтверждение в тикетах.</p>
  </div>
</div>
<?php include 'footer.php'; ?>
