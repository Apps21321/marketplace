<?php include __DIR__ . '/header.php'; ?>

<div class="product-details">
    <h2><?= htmlspecialchars($product['name']) ?></h2>
    <div class="product-description"><?= htmlspecialchars($product['description']) ?></div>
    <div class="product-price"><?= htmlspecialchars($product['price']) ?>$</div>
    <div class="product-seller">
        <h3>Продавец: <?= htmlspecialchars($seller['jabber']) ?></h3>
        <div class="seller-rating">
            <!-- Здесь можно добавить рейтинг продавца -->
        </div>
    </div>
    <button class="add-to-cart">Добавить в корзину</button>
</div>

<?php include __DIR__ . '/footer.php'; ?>
