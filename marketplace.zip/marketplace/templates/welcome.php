<link rel="stylesheet" href="/assets/css/style.css">
<div class="container" style="text-align:center; margin-top:100px;">
  <h2>Добро пожаловать</h2>
  <p>Пожалуйста, войдите или зарегистрируйтесь для доступа к платформе.</p>
  <div style="margin: 20px;">
    <a href="/login"><button>Войти</button></a>
    <a href="/register"><button>Регистрация</button></a>
  </div>
</div>
