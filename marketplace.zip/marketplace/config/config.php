
<?php

return [
    'db' => [
        'host' => 'localhost',
        'dbname' => 'marketplace',
        'user' => 'marketuser',
        'pass' => 'password'
    ],
    'xpub' => 'xpub6938nUeb5LLTAxJjRC8TA53NEhpLQnDvBxobwMNTR3hdNxdLT4rYwHHNwvYm4sfq2sRFK6UpVbmm4X2gwQvm4UaWxPjkVQnDG9M6mG5f97X',
    'btc_api' => 'https://blockstream.info/api',
    'gap_limit' => 20
];
