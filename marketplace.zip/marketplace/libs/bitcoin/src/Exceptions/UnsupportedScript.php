<?php

namespace BitWasp\Bitcoin\Exceptions;

class UnsupportedScript extends \RuntimeException
{

}
