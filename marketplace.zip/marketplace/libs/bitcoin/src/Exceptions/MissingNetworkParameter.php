<?php

namespace BitWasp\Bitcoin\Exceptions;

class MissingNetworkParameter extends \Exception
{

}
