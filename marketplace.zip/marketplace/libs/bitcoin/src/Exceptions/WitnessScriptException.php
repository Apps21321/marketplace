<?php

namespace BitWasp\Bitcoin\Exceptions;

class WitnessScriptException extends \Exception
{

}
