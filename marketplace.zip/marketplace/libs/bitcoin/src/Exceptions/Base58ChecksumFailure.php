<?php

namespace BitWasp\Bitcoin\Exceptions;

class Base58ChecksumFailure extends \Exception
{
}
