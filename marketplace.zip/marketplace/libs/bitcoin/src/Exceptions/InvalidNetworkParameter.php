<?php

namespace BitWasp\Bitcoin\Exceptions;

class InvalidNetworkParameter extends \Exception
{

}
