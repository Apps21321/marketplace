<?php

namespace BitWasp\Bitcoin\Exceptions;

class ScriptHashMismatch extends ScriptQualificationError
{

}
