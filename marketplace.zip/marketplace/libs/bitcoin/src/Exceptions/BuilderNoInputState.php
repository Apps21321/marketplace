<?php

namespace BitWasp\Bitcoin\Exceptions;

class BuilderNoInputState extends \Exception
{
}
