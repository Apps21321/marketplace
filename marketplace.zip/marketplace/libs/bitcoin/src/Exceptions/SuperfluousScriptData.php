<?php

namespace BitWasp\Bitcoin\Exceptions;

class SuperfluousScriptData extends ScriptQualificationError
{

}
