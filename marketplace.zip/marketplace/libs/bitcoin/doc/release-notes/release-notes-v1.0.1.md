v1.0.1
=======

The v1.0.1 is a patch fixing an issue where the secp256k1 extension
was not used because the version was incorrect.

Notable Changes
===============

Bug fixes:
 - #779 - EcAdapterFactory: bump secp256k1 version to v0.2.0, fixes #777

General:
 - #786 - OutPointSerializer: make parsing slightly faster

Credits
=======

A special thanks to everyone who contributed directly to the release:

 - afk11
 - andkom

