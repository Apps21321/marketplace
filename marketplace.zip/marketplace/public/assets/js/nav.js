
document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('createNavForm');
    if (form) {
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(form);
            const response = await fetch(form.action, {
                method: 'POST',
                body: formData
            });
            if (response.ok) {
                alert('Кнопка добавлена');
                location.reload();
            } else {
                alert('Ошибка при добавлении');
            }
        });
    }

    document.querySelectorAll('.delete-nav').forEach(button => {
        button.addEventListener('click', async () => {
            const id = button.dataset.id;
            const response = await fetch('/admin/nav/delete', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'id=' + encodeURIComponent(id)
            });
            if (response.ok) {
                document.getElementById('nav-' + id).remove();
            } else {
                alert('Ошибка удаления');
            }
        });
    });
});
