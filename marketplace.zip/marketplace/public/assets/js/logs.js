
document.addEventListener('DOMContentLoaded', () => {
    console.log('Логи активности загружены');
    // Можно реализовать фильтрацию или обновление без перезагрузки
});
