
document.addEventListener('DOMContentLoaded', () => {
    // Создание пользователя
    const createForm = document.getElementById('createUserForm');
    if (createForm) {
        createForm.addEventListener('submit', async function(event) {
            event.preventDefault();
            const formData = new FormData(this);
            const response = await fetch(this.action, {
                method: 'POST',
                body: formData
            });
            if (response.ok) {
                document.getElementById('responseMessage').style.display = 'block';
                window.location.reload();
            } else {
                alert('Ошибка при создании пользователя');
            }
        });
    }

    // Удаление пользователя
    document.querySelectorAll('.delete-user').forEach(button => {
        button.addEventListener('click', async () => {
            const userId = button.dataset.userId;
            const response = await fetch('/admin/users/delete', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'user_id=' + encodeURIComponent(userId)
            });
            if (response.ok) {
                document.getElementById('user-' + userId).remove();
            }
        });
    });

    // Статус (актив/неактив)
    document.querySelectorAll('.toggle-status').forEach(button => {
        button.addEventListener('click', async () => {
            const userId = button.dataset.userId;
            const currentStatus = button.dataset.currentStatus;
            const newStatus = currentStatus === 'active' ? 'inactive' : 'active';

            const response = await fetch('/admin/users/update_status', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'user_id=' + encodeURIComponent(userId) + '&new_status=' + encodeURIComponent(newStatus)
            });

            if (response.ok) {
                const row = document.getElementById('user-' + userId);
                const statusCell = row.querySelector('.user-status');
                statusCell.textContent = newStatus;
                button.textContent = newStatus === 'active' ? 'Деактивировать' : 'Активировать';
                button.dataset.currentStatus = newStatus;
            }
        });
    });

    // Открытие окна редактирования
    document.querySelectorAll('.edit-user').forEach(button => {
        button.addEventListener('click', async () => {
            const userId = button.dataset.userId;
            const response = await fetch(`/admin/users/details?user_id=${userId}`);
            const data = await response.json();
            document.getElementById('edit_user_id').value = data.id;
            document.getElementById('edit_jabber').value = data.jabber;
            document.getElementById('edit_password').value = '';
            document.getElementById('editUserModal').style.display = 'block';
        });
    });

    // Закрытие модального окна
    const closeModal = document.getElementById('closeEditModal');
    if (closeModal) {
        closeModal.addEventListener('click', () => {
            document.getElementById('editUserModal').style.display = 'none';
        });
    }

    // Сохранение изменений пользователя
    const editForm = document.getElementById('editUserForm');
    if (editForm) {
        editForm.addEventListener('submit', async function(event) {
            event.preventDefault();
            const formData = new FormData(this);
            const response = await fetch('/admin/users/update', {
                method: 'POST',
                body: formData
            });
            if (response.ok) {
                alert('Пользователь обновлён');
                document.getElementById('editUserModal').style.display = 'none';
                window.location.reload();
            } else {
                alert('Ошибка при обновлении пользователя');
            }
        });
    }
});
