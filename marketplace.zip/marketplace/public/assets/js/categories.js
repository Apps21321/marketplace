
document.addEventListener('DOMContentLoaded', () => {
    // Добавление категории
    const form = document.getElementById('createCategoryForm');
    if (form) {
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(form);
            const response = await fetch(form.action, {
                method: 'POST',
                body: formData
            });
            if (response.ok) {
                alert('Категория добавлена');
                location.reload();
            } else {
                alert('Ошибка добавления категории');
            }
        });
    }

    // Удаление категории
    document.querySelectorAll('.delete-category').forEach(button => {
        button.addEventListener('click', async () => {
            const id = button.dataset.id;
            const response = await fetch('/admin/categories/delete', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'id=' + encodeURIComponent(id)
            });
            if (response.ok) {
                document.getElementById('category-' + id).remove();
            } else {
                alert('Ошибка удаления');
            }
        });
    });
});
