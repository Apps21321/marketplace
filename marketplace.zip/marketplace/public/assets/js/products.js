
document.addEventListener('DOMContentLoaded', () => {
    // Добавление товара
    const createForm = document.getElementById('createProductForm');
    if (createForm) {
        createForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(createForm);
            const response = await fetch('/admin/products/create', {
                method: 'POST',
                body: formData
            });
            if (response.ok) {
                alert('Товар добавлен');
                location.reload();
            } else {
                alert('Ошибка при добавлении');
            }
        });
    }

    // Удаление товара
    document.querySelectorAll('.delete-product').forEach(button => {
        button.addEventListener('click', async () => {
            const productId = button.dataset.productId;
            const response = await fetch('/admin/products/delete', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `id=${productId}`
            });
            if (response.ok) {
                document.getElementById('product-' + productId).remove();
            } else {
                alert('Ошибка удаления');
            }
        });
    });

    // Открыть модальное окно
    document.querySelectorAll('.edit-product').forEach(button => {
        button.addEventListener('click', async () => {
            const id = button.dataset.productId;
            const response = await fetch(`/admin/products/details?id=${id}`);
            const data = await response.json();
            document.getElementById('edit_product_id').value = data.id;
            document.getElementById('edit_product_name').value = data.name;
            document.getElementById('edit_product_price').value = data.price;
            document.getElementById('editProductModal').style.display = 'block';
        });
    });

    // Закрыть модальное окно
    document.getElementById('closeEditProductModal').addEventListener('click', () => {
        document.getElementById('editProductModal').style.display = 'none';
    });

    // Сохранить изменения
    const editForm = document.getElementById('editProductForm');
    editForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = new FormData(editForm);
        const response = await fetch('/admin/products/update', {
            method: 'POST',
            body: formData
        });
        if (response.ok) {
            alert('Обновлено');
            document.getElementById('editProductModal').style.display = 'none';
            location.reload();
        } else {
            alert('Ошибка обновления');
        }
    });
});
