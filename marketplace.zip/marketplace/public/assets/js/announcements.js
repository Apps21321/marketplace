
document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('createAnnouncementForm');
    if (form) {
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(form);
            const response = await fetch(form.action, {
                method: 'POST',
                body: formData
            });
            if (response.ok) {
                alert('Объявление добавлено');
                location.reload();
            } else {
                alert('Ошибка добавления');
            }
        });
    }

    document.querySelectorAll('.delete-announcement').forEach(button => {
        button.addEventListener('click', async () => {
            const id = button.dataset.id;
            const response = await fetch('/admin/announcements/delete', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'id=' + encodeURIComponent(id)
            });
            if (response.ok) {
                document.getElementById('announcement-' + id).remove();
            } else {
                alert('Ошибка удаления');
            }
        });
    });
});
