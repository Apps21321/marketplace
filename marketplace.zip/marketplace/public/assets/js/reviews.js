
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.delete-review').forEach(button => {
        button.addEventListener('click', async () => {
            const reviewId = button.dataset.reviewId;
            const response = await fetch('/admin/reviews/delete', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'id=' + encodeURIComponent(reviewId)
            });
            if (response.ok) {
                document.getElementById('review-' + reviewId).remove();
            } else {
                alert('Ошибка удаления отзыва');
            }
        });
    });
});
