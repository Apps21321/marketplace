
document.addEventListener('DOMContentLoaded', () => {
    // Добавление баннера
    const form = document.getElementById('createBannerForm');
    if (form) {
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(form);
            const response = await fetch(form.action, {
                method: 'POST',
                body: formData
            });
            if (response.ok) {
                alert('Баннер добавлен');
                location.reload();
            } else {
                alert('Ошибка при добавлении баннера');
            }
        });
    }

    // Удаление баннера
    document.querySelectorAll('.delete-banner').forEach(button => {
        button.addEventListener('click', async () => {
            const id = button.dataset.id;
            const response = await fetch('/admin/banners/delete', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'id=' + encodeURIComponent(id)
            });
            if (response.ok) {
                document.getElementById('banner-' + id).remove();
            } else {
                alert('Ошибка при удалении');
            }
        });
    });
});
