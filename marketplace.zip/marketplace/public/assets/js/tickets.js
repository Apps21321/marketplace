
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.delete-ticket').forEach(button => {
        button.addEventListener('click', async () => {
            const id = button.dataset.id;
            const response = await fetch('/admin/tickets/delete', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'id=' + encodeURIComponent(id)
            });
            if (response.ok) {
                document.getElementById('ticket-' + id).remove();
            } else {
                alert('Ошибка при удалении тикета');
            }
        });
    });
});
